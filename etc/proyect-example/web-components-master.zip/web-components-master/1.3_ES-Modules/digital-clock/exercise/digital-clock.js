/*
  1- Create a digital-clock component.
  2- Each second, we must calculate the time and update the component HTML
*/
